import './App.css';
import React from 'react';
import Uploader from './components/Uploader/Uploader';
<script src="../rgblind/rgblind.js"></script>
function App() {
  return (
    <div>
    <div className="bg">
    <Uploader />
    </div>
    </div>
  );
}

export default App;
