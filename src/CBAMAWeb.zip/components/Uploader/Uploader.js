import { useState} from 'react'
import './uploader.css'
import {MdCloudUpload} from 'react-icons/md'

function Uploader() {
  const[image, setImage] = useState(null)
  const[fileName, setFileName] = useState("No selected file")
  return (
    <main class="content">
      <div className="banner">
        <div className="banner-content">
        <pre class="header-font">
        C. B. A. M. A. <br></br>
        <p className="sub-header">Color Blind Accessibility Mobile Application</p>
        </pre>
        </div>
      </div>
      <form action="" onClick={() => document.querySelector(".input-field").click()}>
        <input type="file" accept='image/*' className='input-field' hidden
        onChange={({target: {files}}) => {
          files[0] && setFileName(files[0].name)
          if(files){
            setImage(URL.createObjectURL(files[0]))
          }
        }}
        />
        {image ? 
        <img src={image} width={400} height={400} alt={fileName} id='filterableImage'/>
        :
        <>
        <MdCloudUpload color='#1475cf' size={100} />
        <p>Choose Image to Upload</p>
        </>
      }
      </form>
      <div id="gallery">
        <div class="img-text">
            <img src={image} width={400} height={400} position='center' alt={""} className="protanopia"/>
            <p>Protanopia</p>
        </div>
        <div class="img-text">
            <img src={image} width={400} height={400} position='center' alt={""} className="tritanopia"/>
            <p class="img-text">Tritanopia</p>
        </div>
        <div class="img-text">
            <img src={image} width={400} height={400} position='center' alt={""} className="deuteranopia"/>
            <p class="img-text">Deuteranopia</p>
        </div>
      </div>
    </main>
  )
  
}

export default Uploader